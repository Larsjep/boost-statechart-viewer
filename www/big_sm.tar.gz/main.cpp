
#include "machine_header.h"

using namespace std;

MyMachine Zm; // pro posilani udalosti

int main()
{
    Zm.initiate();
    return 0;
}
